import { Component } from '@angular/core';//importing component decorator

@Component({ //decorator
  selector: 'app-root',  
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'] //metadata
})
export class AppComponent {//exporting appcomponent class
  
}


