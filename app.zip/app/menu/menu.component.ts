import { Component, OnInit } from '@angular/core';
import { TennisService } from '../services/tennis.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  private tennisdata:any
  constructor(private tennisservice:TennisService) { }

  ngOnInit() {
    this.tennisdata =this.tennisservice.getTennisdata();
  }

}
