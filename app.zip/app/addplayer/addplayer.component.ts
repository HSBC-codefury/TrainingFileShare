import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addplayer',
  templateUrl: './addplayer.component.html',
  styleUrls: ['./addplayer.component.css']
})
export class AddplayerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
