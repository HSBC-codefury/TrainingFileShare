import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewplayer',
  templateUrl: './viewplayer.component.html',
  styleUrls: ['./viewplayer.component.css']
})
export class ViewplayerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
