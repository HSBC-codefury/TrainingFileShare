import { Injectable } from '@angular/core';
import { footermenudata } from '../models/models.footermenudata';


@Injectable({
  providedIn: 'root' //it will createsinglton object 
})
export class FooterService {

  constructor() { }

  getfooterdata():any{
    return footermenudata
  }


  }
