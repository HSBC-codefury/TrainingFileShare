import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchplayer',
  templateUrl: './searchplayer.component.html',
  styleUrls: ['./searchplayer.component.css']
})
export class SearchplayerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
