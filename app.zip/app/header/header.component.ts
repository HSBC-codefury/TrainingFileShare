import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  private title:string
  private logo:string
  constructor() { 

    this.title='Tennis championship 2019-20'
    this.logo="../assets/tennislogo.png"
  }

  ngOnInit() {
  }

}
