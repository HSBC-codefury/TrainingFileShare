export class TennisMenu {
    private _label: string
    public get label(): string {
        return this._label
    }
    // public set label(value: string) {
    //     this._label = value
    // }
    private _icon: string
    public get icon(): string {
        return this._icon
    }
    // public set icon(value: string) {
    //     this._icon = value
    // }
    private _routerLink: string
    public get routerLink(): string {
        return this._routerLink
    }
   
    constructor(label:string,icon:string,routerlink:string){
        this._label = label
        this._icon=icon
        this._routerLink=routerlink    }

    

    


}