package com.hsbc.sports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day17springbootsportsapplnApplicationTests {

	@Test
	void contextLoads() {
	}

}
