//declaration
//return type void
function message() {
    console.log("We are using Typescript....!!!!");
}
function readCustomerInfo(CustomerId, name, dob) {
    return CustomerId + " " + name + " " + dob.toLocaleDateString();
}
//implementation
function greet(name, message) {
    console.log(name + message);
}
greet("Naman", " is best");
greet("Naman", 3);
//invoke
message();
console.log(readCustomerInfo(3, "naman", new Date()));
