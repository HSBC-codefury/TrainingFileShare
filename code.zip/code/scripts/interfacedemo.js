//annonymus object.
let india = { name: "India", capital: "delhi", currency: "INR", population: 120 };
console.log("population", india.population);
//annonymus object.
let asia = { name: "India", population: 120 };
console.log("population", asia.population);
//method implementation.
let usVisa = (process, number) => {
    console.log(`visa processing data, ${process}`);
};
//invoking
usVisa('HIB', 10);
