export class Traveller {
    //properties
    get passportNo() {
        return this._passportNo;
    }
    set passportNo(value) {
        this._passportNo = value;
    }
    get firstName() {
        return this._firstName;
    }
    set firstName(value) {
        this._firstName = value;
    }
    get lastName() {
        return this._lastName;
    }
    set lastName(value) {
        this._lastName = value;
    }
    get dob() {
        return this._dob;
    }
    set dob(value) {
        this._dob = value;
    }
    get bankBalance() {
        return this._bankBalance;
    }
    set bankBalance(value) {
        this._bankBalance = value;
    }
    //method at class level.
    addMoney(amount) {
        this._bankBalance += amount;
    }
}
