//declaration
//return type void
function message(): void {
    console.log("We are using Typescript....!!!!");
}

function readCustomerInfo(CustomerId: number, name: string, dob: Date): string {
    return CustomerId + " " + name + " " + dob.toLocaleDateString();
}

//function overloading decleration
function greet(name:string,message:number):void;
function greet(name:string,message:string):string;

//implementation
function greet(name:any,message:any):any
{
    console.log(name +  message);
}

greet("Naman"," is best");
greet("Naman", 3);

//invoke
message();
console.log(readCustomerInfo(3,"naman",new Date()));