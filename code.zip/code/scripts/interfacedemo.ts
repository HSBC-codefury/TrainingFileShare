interface Country{
    name:string;
    capital:string;
    currency:string;
    population:number;
}

//annonymus object.
let india:Country={name:"India",capital:"delhi",currency:"INR",population:120};
console.log("population",india.population);

//putting question mark will make the property optional.
interface Continent{
    name:string;
    capital?:string;
    currency?:string;
    population:number;
}

//annonymus object.
let asia:Continent={name:"India",population:120};
console.log("population",asia.population);

//demonstaation of interface abstract method.
interface visa{
    (process:string,number):any; //abstract method
}

//method implementation.
let usVisa=(process:string,number)=>{
    console.log(`visa processing data, ${process}`);
}


//invoking
usVisa('HIB', 10);