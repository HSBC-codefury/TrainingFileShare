//Declare variables
var gender;
(function (gender) {
    gender[gender["MALE"] = 0] = "MALE";
    gender[gender["FEMALE"] = 1] = "FEMALE";
})(gender || (gender = {}));
var firstName;
var lastName;
var dob;
var active;
var membershipId;
var genderType;
var skills;
var account;
//Assign values
firstName = "Naman";
lastName = "Khandelwal";
dob = new Date(1999, 1, 5);
active = true;
membershipId = 435435345;
genderType = gender.FEMALE;
skills = ["JAVA", "PYTHONS", "C++"];
account = ["Naman", 22, "Smart"];
//Display the results
console.log("First Name " + firstName + "\nLast Name " + lastName + "\nDate of Birth " + dob + "\nActive " + active +
    "\nMembership Id " + membershipId + "\ngender type " + gender[genderType]);
//arrow function.
console.log("Skills ....");
skills.forEach(function (skill) {
    console.log(skill);
});
console.log("Account details ....");
account.forEach(function (elemt) {
    console.log(elemt);
});
