
export class Traveller {

    //fields
    private _passportNo: string;
    private _firstName: string;
    private _lastName: string;
    private _dob: Date;
    private _bankBalance: number;

    //properties


    get passportNo(): string {
        return this._passportNo;
    }

    set passportNo(value: string) {
        this._passportNo = value;
    }

    get firstName(): string {
        return this._firstName;
    }

    set firstName(value: string) {
        this._firstName = value;
    }

    get lastName(): string {
        return this._lastName;
    }

    set lastName(value: string) {
        this._lastName = value;
    }

    get dob(): Date {
        return this._dob;
    }

    set dob(value: Date) {
        this._dob = value;
    }

    get bankBalance(): number {
        return this._bankBalance;
    }

    set bankBalance(value: number) {
        this._bankBalance = value;
    }

    //method at class level.
    public addMoney(amount: number): void {
        this._bankBalance += amount;
    }

}

