import{Traveller} from "./traveller"

let traveller = new Traveller();
//setters
traveller.firstName = "Naman";
traveller.lastName = "Khandelwal";
traveller.passportNo = "K787997";
traveller.dob = new Date();
traveller.bankBalance = 8787545;
console.log("Initial Bank balance", traveller.bankBalance);
traveller.addMoney(155);
console.log("Final Bank balance", traveller.bankBalance);
//getters
console.log("\nFirst Name", traveller.firstName);
console.log("Cuurent date", traveller.dob); 