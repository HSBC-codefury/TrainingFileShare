//Declare variables

enum gender{MALE,FEMALE}
let firstName: string;
let lastName: string;
let dob: Date;
let active: boolean;
let membershipId: number;
let genderType: gender;
let skills: string[];
let account:any[];


//Assign values
firstName="Naman";
lastName="Khandelwal";
dob=new Date(1999,1,5);
active=true;
membershipId=435435345;
genderType=gender.FEMALE;
skills=["JAVA", "PYTHONS", "C++"];
account=["Naman",22,"Smart"];

//Display the results
console.log("First Name "+firstName+"\nLast Name "+lastName+"\nDate of Birth "+dob+"\nActive "+active+
"\nMembership Id "+membershipId + "\ngender type " + gender[genderType]);

//arrow function.
console.log("Skills ....")
skills.forEach(skill=>{
    console.log(skill);
});


console.log("Account details ....")
account.forEach(elemt=>{
    console.log(elemt);
});