package com.hsbc.retail.models;

public enum MaterialType {

	Woolen,Cotton
}
