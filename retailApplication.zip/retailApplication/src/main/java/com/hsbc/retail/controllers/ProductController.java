package com.hsbc.retail.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hsbc.retail.models.FoodItems;
import com.hsbc.retail.services.ProductService;

@RestController
public class ProductController {
	@Autowired
	private ProductService productService;
	
	
	public @ResponseBody FoodItems addFoodItem(@RequestBody FoodItems foodItems)
	{
		return productService.addFoodItem(foodItems);
	}
}
