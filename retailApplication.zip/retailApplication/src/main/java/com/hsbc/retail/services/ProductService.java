package com.hsbc.retail.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsbc.retail.models.Electronics;
import com.hsbc.retail.models.FoodItems;
import com.hsbc.retail.repositories.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepo;
	
	public FoodItems addFoodItem(FoodItems foodItems)
	{
		return this.productRepo.save(foodItems);
	}
	public Electronics addElectronics(Electronics electronics)
	{
		return this.productRepo.save(electronics);
	}
}
