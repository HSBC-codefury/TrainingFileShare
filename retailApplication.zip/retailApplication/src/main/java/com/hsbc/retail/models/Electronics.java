package com.hsbc.retail.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="Electronics")
public class Electronics extends Product {

	@Column(name="Warranty")
	private byte warranty; 
	
	public void setWarranty(byte warranty) {
		this.warranty = warranty;
	}
	public byte getWarranty() {
		return warranty;
	}
	
	
	
}
